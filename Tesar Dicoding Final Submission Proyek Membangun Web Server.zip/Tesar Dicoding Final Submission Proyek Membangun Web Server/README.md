# A387-Jarkom-Labs

Untuk menjalankan project ini, pastikan `npm` sudah terinstall pada komputer/laptop Anda.

---

Tata cara menjalankan project:

1. Install node modules

```
npm install
```

2. Jalankan project

```
npm run start
```
